<?php

 $host="localhost";
 $dbusername="root";
 $dbpassword="";
 $db="hotel_booking";

$conn=mysqli_connect($host,$dbusername,$dbpassword,$db) or die("connection failed");





?>