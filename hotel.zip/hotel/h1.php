<?php
include('session.php');
?>

<html>
<head>
<title>
Home page </title>
<style>
.page{
	width: 100%;
	height:auto;
	border-style: groove;
    background-color: #dcdfc1;
}

.headerpart
{
	width:100%;
	height: 42px;
	background-color: red;
	padding-top: 15px;
	
}

.headerpart a{
	text-align: middle;
	bottom:10px;
	text-align: justify;
	text-decoration: blink;
	margin-bottom: px;
}
.headerpart a:hover{
	background-color: white;

}
.headerpart a:active{
	background-color: white;
}
 .leftpart
{
	
	width:100%;
	height: auto%;
	border-style: groove;


     

     background-repeat: no-repeat;
	background-color: white;
    
	


}
</style>
<link rel="stylesheet" type="text/css" href="new_home.css">
<body>
	<div class="page">
		<div class="headerpart">
			<center>		
		    <a href="h1.php" >HOME</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<a href="aboutus.php">ABOUT US</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<a href="search.html">RESERVATION</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<a href="cust_registration.php">NEW CUSTOMER</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<a href="contactus.php">CONTACT US</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<a href="logout.php">LOG OUT</a>
		</center>
			
		</div>
<div class="leftpart">
<img src="s1.png" width="100%" height="100%">
<img src="s2.png" width="100%" height="100%">
<img src="s3.png" width="100%" height="100%">
<img src="s4.png" width="100%" height="100%">

  </div>

           	<a style="font-size: 30px" href="view_detail.html">View Bokking Details</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
           	
           	<a style="font-size: 30px" href="r_man.html">Room Maintainance</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

           		<a style="font-size: 30px" href="cancellation.php">Cancel Reservation</a>
           

		</div>
</body>
</html>